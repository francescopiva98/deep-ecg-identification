# FUNCTIONS
# 1) data_from_csv;
# 2) loading_data;
# 3) sampling_rate

import os
import pandas as pd
import numpy as np
from utils import data_conv2

# 1) data_from_csv function
def data_from_csv(data_df):
    
    # tolgo i valori NaN su colonne specifiche
    data_df_notnan = data_df.dropna(subset = ['ECGTimestamps','ECGString'])

    # ECG decoding
    ecg_signal = []
    for sample in data_df_notnan["ECGString"]:      
        array_data = bytearray()
        vec = np.arange(0, len(sample), 2)

        for index in vec:
            tmp = sample[index:index + 2]
            tmp2 = int(tmp, 16)
            array_data.append(int(tmp2))
    
        ecg_track = data_conv2(array_data)
        ecg_signal.extend(ecg_track)
    
    # ECG time
    ecg_timestamps = (data_df_notnan["ECGTimestamps"] - data_df_notnan["ECGTimestamps"].iloc[0])/1000     # seconds starting from 0 
    ecg_time = []

    for i in range(len(ecg_timestamps)):
        for j in range(len(ecg_track)):
            if i < len(ecg_timestamps)-1:
                sample = ecg_timestamps[i] + (ecg_timestamps[i+1] - ecg_timestamps[i])/len(ecg_track)*j
                ecg_time.append(sample)
            else: # Last segment
                sample = ecg_timestamps[i] + (ecg_timestamps[i] - ecg_timestamps[i-1])/len(ecg_track)*j
                ecg_time.append(sample)

    # PPG signal
    ppg_signal = data_df["PPGvalue"]
    ppg_time = (data_df["OXYTimestamps"] - data_df["OXYTimestamps"].iloc[0])/1000 # seconds starting from 0 

    # HR signal
    hr_signal = data_df["HRvalue"]
    hr_time = (data_df["HRTimestamps"] - data_df["HRTimestamps"].iloc[0])/1000 #seconds starting from 0 

    # SpO2 signal
    spo2_signal = data_df["SpO2value"]
    
    #convert to ndarray
    ecg_signal = np.array(ecg_signal)
    ecg_time = np.array(ecg_time)
    hr_signal = np.array(hr_signal)
    hr_time = np.array(hr_time)
    ppg_signal = np.array(ppg_signal)
    ppg_time = np.array(ppg_time)
    spo2_signal = np.array(spo2_signal)

    return ecg_signal, ecg_time, ppg_signal, ppg_time #hr_signal, hr_time, , spo2_signal

# 2) Load_data function
def load_data(data_path1, data_path2):
  
  data_dict_rest = {} #dictionary che contiene tutti i data_frame (tabella estratta dal csv)
  data_dict_task = {}

  for root, dirs, files in os.walk(data_path1):
    for file in files:
      # chiamare ogni file "nome_soggetto.csv
      idx = file.rfind(".")
      subj_name = file[:idx] #prendi il file .csv e rimuovi .csv (rimane solo il nome)
    
      data_df_temp = pd.read_csv(os.path.join(root, file), delimiter = '\t')
      ecg_signal, ecg_time, ppg_signal, ppg_time  = data_from_csv(data_df_temp)
    
      print(subj_name, ecg_signal.shape, ecg_time.shape, ppg_signal.shape, ppg_time.shape)#,hr_signal.shape, hr_time.shape, ppg_signal.shape, ppg_time.shape, spo2_signal.shape)

      df_cardiofreq_rest = pd.DataFrame(columns = ['ECG time grid', 'raw ECG signal',]) #per ogni singolo soggetto
      df_sat_rest = pd.DataFrame(columns = ['ppg time grid', 'raw ppg signal']) #per ogni singolo soggetto
      
      df_cardiofreq_rest['ECG time grid'] = ecg_time
      df_cardiofreq_rest['raw ECG signal'] = ecg_signal

      df_sat_rest['ppg time grid'] = ppg_time
      df_sat_rest['raw ppg signal'] = ppg_signal
      
      data_dict_rest[f'{subj_name}'] = [df_cardiofreq_rest, df_sat_rest]

  for root, dirs, files in os.walk(data_path2):
    for file in files:
      idx = file.rfind(".")
      subj_name = file[:idx] #prendi il file .csv e rimuovi .csv (rimane solo il nome)
      
      data_df_temp = pd.read_csv(os.path.join(root, file), delimiter = '\t')
      ecg_signal, ecg_time, ppg_signal, ppg_time  = data_from_csv(data_df_temp)
      
      print(subj_name, ecg_signal.shape, ecg_time.shape, ppg_signal.shape, ppg_time.shape)#,hr_signal.shape, hr_time.shape, ppg_signal.shape, ppg_time.shape, spo2_signal.shape)

      df_cardiofreq = pd.DataFrame(columns = ['ECG time grid', 'raw ECG signal']) #per ogni singolo soggetto
      df_sat = pd.DataFrame(columns = ['ppg time grid', 'raw ppg signal']) #per ogni singolo soggetto
      
      df_cardiofreq['ECG time grid'] = ecg_time
      df_cardiofreq['raw ECG signal'] = ecg_signal

      df_sat['ppg time grid'] = ppg_time
      df_sat['raw ppg signal'] = ppg_signal
      
      data_dict_task[f'{subj_name}'] = [df_cardiofreq, df_sat]
  
  return data_dict_rest, data_dict_task

# 3) fs calculation
def sampling_rate(data_dict):
    
    fs_dict = {} #dictionary vuoto

    for key, value in data_dict.items():
      
      timegrid_ecg = value[0]['ECG time grid']
      timegrid_ppg = value[1]['ppg time grid']

      temp_ecg = np.zeros(shape = timegrid_ecg.size-1)
      temp_ppg = np.zeros(shape = timegrid_ppg.size-1)
      
      #calcola tutte le fs spostandosi di una posizione alla volta e le salva su un array (ecg)
      for i in range(0, timegrid_ecg.size-1, 1):
        temp_ecg[i] = np.round(1/(timegrid_ecg[i+1] - timegrid_ecg[i]))

      fs_ecg = np.round(np.mean(temp_ecg))

      #calcola tutte le fs spostandosi di una posizione alla volta e le salva su un array (ppg)
      for i in range(0, timegrid_ppg.size-1, 1):
        if timegrid_ppg[i+1] - timegrid_ppg[i] != 0: #se la differenza è 0 esce fs pari a infinito
          temp_ppg[i] = np.round(1/(timegrid_ppg[i+1] - timegrid_ppg[i]))
      
      fs_ppg = np.round(np.mean(temp_ppg))

      fs_dict[f'{key}'] = [fs_ecg, fs_ppg]
    
    return fs_dict