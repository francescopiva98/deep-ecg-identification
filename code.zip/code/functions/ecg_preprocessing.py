#ECG pre-processing

# 1) segment_ECG
# 2) matrix_to_signal

import numpy as np
import os
import pandas as pd
from matplotlib.gridspec import GridSpec
from ecgdetectors import Detectors
from scipy.signal import resample
from utils import data_conv2

# 1) ECG SEGMENTATION
def segment_ECG(ecg_signal, fs = 130, word_len = 100):
    detectors = Detectors(fs)
    r_peaks = detectors.two_average_detector(np.squeeze(ecg_signal))
    ecg_matrix = []
    original_len = []
    for i in range(len(r_peaks)-1):
        ecg_segment = np.array((ecg_signal[r_peaks[i]:r_peaks[i+1]]).reshape(1,-1)[0])
        original_len.append(len(ecg_segment))
        ecg_word = resample(ecg_segment, 100)
        ecg_matrix.append(ecg_word)

    ecg_matrix = np.array(ecg_matrix)
    return ecg_matrix, r_peaks, original_len


# 2) ECG signal reconstruction
def matrix_to_signal(matrix, original_len = None):
    if original_len == None:
        signal = matrix.reshape(-1,1,order = 'C')
    else:  
        signal = []
        for i in range(len(original_len)):
            ecg_word = resample(matrix[-len(original_len)+i,:], original_len[-len(original_len)+i])
            signal.extend(ecg_word)
        signal = np.array(signal)
    return signal