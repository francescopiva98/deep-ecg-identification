from matplotlib.pyplot import figure
from scipy import signal, fft
from scipy.signal import butter, iirnotch, lfilter, filtfilt, freqz
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

# 1) NORMALIZATION (va applicata separatamente a seconda se si voglia normalizzare l'ECG o il ppg)

def normalize_data(data_dict, is_ecg): 
  norm_data = {} #dictionary che contiene i dati normalizzati

  for key, value in data_dict.items():
    if is_ecg:
      df_normecg = pd.DataFrame(columns = ['ECG normalized'])
      #df_normecg['ECG timegrid'] = value[0]['ECG time grid']

      # Amplitude estimate
      norm_factor = np.percentile(value[0]['ECG signal'], 99) - np.percentile(value[0]['ECG signal'], 5)
      norm_ecg = value[0]['ECG signal']/norm_factor

      df_normecg['ECG normalized'] = norm_ecg

      norm_data[f'{key}'] = [df_normecg]

    else:
      df_normppg = pd.DataFrame(columns = ['ppg normalized'])
      #df_normppg['ppg timegrid'] = value[1]['ppg time grid']

      # Amplitude estimate
      norm_factor = np.percentile(value[0]['ECG signal'], 99) - np.percentile(value[0]['ECG signal'], 5)
      norm_ppg = value[1]['ppg signal']/norm_factor

      df_normppg['ppg normalized'] = norm_ppg

      norm_data[f'{key}'] = [df_normppg]
    return norm_data

# 2) Baseline wander removal
def baseline_wander_removal(data_dict, fs_dict, is_ecg):
 
  bs_removal = {} #dictionary

  for key, value in data_dict.items():
    if is_ecg: #cambia la frequenza tra cardiofrequenzimetro e saturimetro
      fs = fs_dict[key][0]
      df_bs_removal = pd.DataFrame(columns= ['ECG after baseline wander removal'])
    else:
      fs = fs_dict[key][1]
      df_bs_removal = pd.DataFrame(columns= ['ppg after baseline wander removal'])
    
    norm_data = value[0]
    ### FIRST WINDOW ###
    win_size = int(np.round(0.2 * fs))
    if win_size % 2 == 0:
      win_size = win_size + 1
    baseline = medfilt(norm_data, win_size)

    ### SECOND WINDOW ###  
    win_size = int(np.round(0.6 * fs))
    if win_size % 2 == 0:
      win_size = win_size + 1
    baseline = medfilt(baseline, win_size)

    # Removing baseline
    filt_data = norm_data - baseline
    
    if is_ecg:
      df_bs_removal['ECG after baseline wander removal'] = filt_data
    else:
      df_bs_removal['ppg after baseline wander removal'] = filt_data

    bs_removal[f'{key}'] = [df_bs_removal]
    
    return bs_removal
    
    #else:
      #fs = fs_dict['key'][1]
      #norm_data = value[0]
      #df_bs_removal = pd.DataFrame(columns= ['ppg time grid', 'ppg after baseline wander removal'])
      #df_bs_removal['ppg time grid'] = norm_data[0]['ppg time grid']

      ### FIRST WINDOW ###
      #win_size = int(np.round(0.2 * fs))
      #if win_size % 2 == 0:
        #win_size = win_size + 1
      #baseline = medfilt(norm_data, win_size)
  
      ### SECOND WINDOW ###  
      #win_size = int(np.round(0.6 * fs))
      #if win_size % 2 == 0:
        #win_size = win_size + 1
      #baseline = medfilt(baseline, win_size)

      # Removing baseline
      #filt_data = norm_data - baseline
      
      #df_bs_removal['ppg after baseline wander removal'] = filt_data
      #bs_removal[f'{key}'] = [df_bs_removal]
      
     # return bs_removal

# 3) Band-pass filter
def butter_bandpass_filter(data_dict, fs_dict, lowcut, highcut, order, is_ecg):
  
  filter_data = {}

  for key, value in data_dict.items():
    if is_ecg:
      df_filter = pd.DataFrame(columns = ['ECG after bandpass filter'])
      fs = fs_dict[key][0]
    else:
      df_filter = pd.DataFrame(columns = ['ECG after bandpass filter'])
      fs = fs_dict[key][1]

    data = data_dict[0]['ECG after baseline wander removal']
    
    b, a = butter(order, [lowcut, highcut],fs=fs, btype='bandpass')
    y = filtfilt(b,a,data) #applica il filtro
    
    if is_ecg:
      df_filter['ECG after bandpass filter'] = y
    else:
      df_filter['ppg after bandpass filter'] =

    filter_data[f'{key}'] = [df_filter]

    return filter_data
    
    #else:
      #df_filter = pd.DataFrame(columns = ['ppg time grid', 'ppg after bandpass filter'])
      #df_filter['ppg time grid'] = value[0]['ppg time grid']

      #data = bs_removal[0]['ppg after baseline wander removal']
      #fs = fs_dict[key][1]

      #b, a = butter(order, [lowcut, highcut],fs=fs, btype='bandpass')
      #y = filtfilt(b,a,data) #applica il filtro
      
      #df_filter['ppg after bandpass filter'] = y

      #filter_data[f'{key}'] = [df_filter]
      
      #return filter_data

#def butter_bandpass(lowcut, highcut, order, fs):
#for order in [3, 6, 8]:
  #b, a = butter_bandpass(lowcut= 0.6,highcut = 50, fs=135, order=order)
  #w, h = freqz(b, a, fs=fs, worN=2000)
  #plt.plot(w, abs(h), label="order = %d" % order)
  #plt.plot(w, np.angle(h), label="order = %d" % order)

  #plt.plot([0, 0.5 * fs], [np.sqrt(0.5), np.sqrt(0.5)],'--', label='sqrt(0.5)')
  #plt.xlabel('Frequency (Hz)')
  #plt.ylabel('Gain')
  #plt.grid(True)
  #plt.legend(loc='best')

# 4) EMG filter
def emg_stopband_filter(data_dict):
    
    b = [0.125, 0, 0, 0, 0, 0, 0, 0, -0.125]
    a = [1, -1]
    
    for key, value in data_dict.items():
      data = value[0]
      y = lfilter(b,a, data)
      return y

#def emg_stopband(): #sistemare
  #b = [0.125, 0, 0, 0, 0, 0, 0, 0, -0.125]
  #a = [1, -1]
  #w, h = freqz(b, a, 131)
  
  # Plot the frequency response for a few different orders.
  #plt.figure(constrained_layout=True, figsize=(30,8))
  #plt.clf()
   
  #plt.plot(w, abs(h))

  #plt.figure(constrained_layout=True, figsize=(30,8))
  #plt.plot(w, np.angle(h))

  #plt.plot([0, 0.5 * 135], [np.sqrt(0.5), np.sqrt(0.5)],'--', label='sqrt(0.5)')
  #plt.xlabel('Frequency (Hz)')
  #plt.ylabel('Gain')
  #plt.grid(True)


# 5) High-pass filter
def butter_highpass_filter(data_dict, fs_dict): #teoricamente si applica solo al ppg
    
    for key, value in data_dict.items():
      fs = fs_dict[key][1]
      data = value[0]
      df_highpass = pd.DataFrame(columns = 'ppg after highpass filter')
      
      b, a = butter(order, lowcut, fs = fs, btype = 'highpass')
      y = filtfilt(b,a,data) #applica il filtro

      df_highpass['ppg after highpass filter'] = y
  return df_highpass

#def butter_highpass(lowcut, order, fs): #non funziona, sistemare
  #b, a = butter(order, lowcut, fs, btype = 'highpass')
  #w, h = freqz(b, a, fs=fs, worN=2000)
  #plt.figure(constrained_layout=True, figsize=(30,16))
   
  #plt.subplot(211)
  #plt.plot(w, abs(h), label="order = %d" % order)
  #plt.xlabel('Frequency (Hz)')
  #plt.ylabel('Gain')
  #plt.grid(True)

  #plt.subplot(212)
  #plt.plot(w, np.angle(h), label="order = %d" % order)

# 6) Notch filter
#bw = 120
#q = (60/(fs/2))/bw;
#print(q)
#def notch(cutoff_stop, q, fs):
    #b, a = iirnotch(cutoff_stop, q, fs = fs)
    #return b, a

#def notch_filter(data, cutoff_stop, q, fs):
    #b,a = notch(cutoff_stop, q, fs = fs)
    #z = lfilter(b,a,data)
    #return z

#plt.figure(constrained_layout=True, figsize=(30,8))
#for q in [10, 30, 50]:
  #b, a = notch(cutoff_stop= 50, q=q , fs = 135)
  #w, h = freqz(b, a, fs=fs, worN=2000)
  #plt.plot(w, abs(h), label= "Quality = %d" % q)
  #plt.plot(w, np.angle(h), label="Quality = %d" % order)

#plt.xlabel('Frequency (Hz)')
#plt.ylabel('Gain')
#plt.grid(True)
#plt.legend(loc='best')



# 7 ) Stop-band filter
#def butter_stopband(low_cut,high_cut, fs, order):
    #nyq = 0.5*fs
    #lowcut_norm = lowcut/nyq
    #highcut_norm = highcut/nyq
    #return butter(order, cutoff_stop, fs=fs, btype='bandstop')

#def butter_stopband_filter(cutoff_stop, highcut, fs, order):
    #b, a = butter_stopband(cutoff_stop, fs, order=order)
    #y = lfilter(b, a, data)
    #print (b)
    #print(a)
    #return y

