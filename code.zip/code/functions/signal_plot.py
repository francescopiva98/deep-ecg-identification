#FUNCTIONS:
# 1) signal_plot
# 2) signal_plot_subj
# 3) ECG plot zoom subj
# 4) spectrum plot

from matplotlib.pyplot import figure
from matplotlib.gridspec import GridSpec
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from loading_data import sampling_rate

# 1) FUNZIONE CHE FA IL PLOT DI TUTTI I SEGNALI SPECIFICATI CON CHIAVE-VALORE
def signal_plot(data_dict, is_ecg):
    for key, value in data_dict.items(): #.items è un metodo che permette di estarre la coppia chiave/valore nel dizionario
      
      #Tolgo la parte _task
      idx = key.rfind('_')
      name = key[:idx]

      if is_ecg:
        plt.figure(constrained_layout=True, figsize=(30,8)) #crea la figura
 
        plt.title(f'{name}: Raw ECG signal (whole recording)', fontsize = 10) #f = format: formatto la stringa mettendoci delle variabili nelle stringhe
        plt.plot(value[0]['ECG time grid'], value[0]['ECG signal'], 'r')
        plt.xlabel('Time (s)')
        plt.ylabel('ECG(mV)')
     
      else:
        plt.figure(constrained_layout=True, figsize=(30,8)) #crea la figura
        
        plt.title('Raw ppg signal (whole recording)', fontsize = 10)
        plt.plot(value[1]['ppg time grid'], value[1]['ppg signal'], 'b')
        plt.xlabel('Time (s)')
        plt.ylabel('ppg(mV)')
      
      plt.show()

# 2) FUNZIONE CHE FA IL PLOT DELL'ECG/PPG PER OGNI SOGGETTO
def signal_plot_subj(data_dict):
    for key, value in data_dict.items(): #.items è un metodo che permette di estarre la coppia chiave/valore nel dizionario
      
      #Tolgo la parte _task
      idx = key.rfind('_')
      name = key[:idx]

      plt.figure(constrained_layout=True, figsize=(30,16)) #crea la figura
      
      plt.subplot(211)
      plt.title(f'{name}: Raw ECG signal (whole recording)', fontsize = 10) #f = format: formatto la stringa mettendoci delle variabili nelle stringhe
      plt.plot(value[0]['ECG time grid'], value[0]['ECG signal'], 'r')
      plt.xlabel('Time (s)')
      plt.ylabel('ECG(mV)')
      
      plt.subplot(212)
      plt.title(f'{name}: Raw ppg signal (whole recording)', fontsize = 10)
      plt.plot(value[1]['ppg time grid'], value[1]['ppg signal'], 'b')
      plt.xlabel('Time (s)')
      plt.ylabel('ppg(mV)')
      
      plt.show()

# 3) FUNZIONE CHE VA IL PLOT DELLA PORZIONE DELL'ECG D'INTERESSE
def signal_plot_subj_zoom(data_dict, i, j):
    for key, value in data_dict.items(): #.items è un metodo che permette di estarre la coppia chiave/valore nel dizionario
      
      #Tolgo la parte _task
      idx = key.rfind('_')
      name = key[:idx]
      
      plt.figure(constrained_layout=True, figsize=(30,8)) #crea la figura

      plt.subplot(211)
      plt.title(f'{name}: Raw ECG signal (whole recording)', fontsize = 10) #f = format: formatto la stringa mettendoci delle variabili nelle stringhe
      plt.plot(value[0]['ECG time grid'][i:j], value[0]['ECG signal'][i:j], 'r')
      plt.xlabel('Time (s)')
      plt.ylabel('ECG(mV)')
      
      plt.subplot(212)
      plt.title(f'{name}: Raw ppg signal (whole recording)', fontsize = 10)
      plt.plot(value[1]['ppg time grid'][i:j], value[1]['ppg signal'][i:j], 'b')
      plt.xlabel('Time (s)')
      plt.ylabel('ppg(mV)')
      
      

      plt.show()

# 4) Spectrum function
def spectrum(data_dict, fs_dict):
  
    for key, value in data_dict.items():

        fs_ecg = fs_dict[key][0]
        fs_ppg = fs_dict[key][0]
        
        signal_ecg = np.array(value[0]['ECG signal'])
        signal_ppg = np.array(value[1]['ppg signal'])
       
        signal_ecg = signal_ecg - np.mean(signal_ecg) #per fare lo spettro si toglie la media
        signal_ppg = signal_ppg - np.mean(signal_ppg)  #per fare lo spettro si toglie la media

        n_ecg = signal_ecg.size
        n_ppg = signal_ppg.size

        X_ecg = fft.fft(signal_ecg)
        X_ppg = fft.fft(signal_ppg)

        pow_spect_ecg = abs(X_ecg)**2/n_ecg
        pow_spect_ppg = abs(X_ppg)**2/n_ppg
        
        #PLOT    
        timestep_ecg = 1/fs_ecg
        timestep_ppg = 1/fs_ppg

        freq_ecg = np.fft.fftfreq(n_ecg, d=timestep_ecg)
        freq_ppg = np.fft.fftfreq(n_ppg, d=timestep_ppg)
        
        #Tolgo la parte _task
        idx = key.rfind('_')
        name = key[:idx]

        plt.figure(constrained_layout=True, figsize=(30,16))

        plt.subplot(211)
        plt.title(f'{name}: ECG spectrum', fontsize = 10) #f = format: formatto la stringa mettendoci delle variabili nelle stringhe
        plt.plot(freq_ecg[:round(freq_ecg.size/2)],pow_spect_ecg[:round(pow_spect_ecg.size/2)], 'r')
        
        plt.subplot(212)
        plt.title(f'{name}: ppg spectrum', fontsize = 10) #f = format: formatto la stringa mettendoci delle variabili nelle stringhe
        plt.plot(freq_ppg[:round(freq_ppg.size/2)],pow_spect_ppg[:round(pow_spect_ppg.size/2)], 'b')

        plt.show()